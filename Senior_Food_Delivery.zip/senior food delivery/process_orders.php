<?php
// Start or resume a session
session_start();

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the submitted item
    $item = $_POST["item"];

    // Initialize the cart array in the session if not already set
    if (!isset($_SESSION["cart"])) {
        $_SESSION["cart"] = array();
    }

    // Add the item to the cart
    $_SESSION["cart"][] = $item;

    // Display a confirmation message
    echo "Item added to the cart: $item";
}
?>
