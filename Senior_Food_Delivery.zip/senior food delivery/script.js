// Add a class to the active link based on the current URL
document.addEventListener("DOMContentLoaded", function () {
    var currentUrl = window.location.href;

    // Select all anchor elements in the navigation
    var navLinks = document.querySelectorAll("nav a");

    // Iterate through each anchor and add the 'active' class if the href matches the current URL
    navLinks.forEach(function (link) {
        if (link.href === currentUrl) {
            link.classList.add("active");
        }
    });
});
