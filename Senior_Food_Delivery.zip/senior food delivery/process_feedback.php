<?php
// Establish database connection
$servername = "127.0.0.1"; // Replace with your database host
$username = "root@localhost"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "senior_food_delivery"; // Replace with your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get feedback data from the form
$name = $_POST['name'];
$email = $_POST['email'];
$rating = $_POST['rating'];
$comments = $_POST['comments'];


// Insert feedback into the database
$sql = "INSERT INTO feedback (name, email, rating, comments) VALUES ('$name', '$email', '$rating', '$comments')";

if ($conn->query($sql) === TRUE) {
    echo "Feedback submitted successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the database connection
$conn->close();
?>
